
package com.hcl.taf;


public class Identity {

    public String IdentifierType;
    public String Identifier;
    public String IdentifierType2;
    public String Identifier2;
    public String IdentifierZone;
    public String IdentifierIndex;
    public int IdentifierIndex1;

}
